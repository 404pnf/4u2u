{
	clips: [
		{ url: 'honda_accord.flv', name: 'Honda commercial', suggestedClipsInfoUrl: 'suggestions.js',
					duration: 180, thumbnailUrl: 'Thumb1.jpg', 
					info: { viewed: 631, category: 'ads' } },
		{ url: 'river.flv', name: 'Skiing in Rovaniemi', suggestedClipsInfoUrl: 'suggestions.js',
					duration: 180, thumbnailUrl: 'Thumb2.jpg',
					info: { viewed: 2, category: 'sports' } }
	]
}